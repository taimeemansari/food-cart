const initialState = {

}
const reducer = (state = initialState, actions) => {
    return state
}

export default reducer;