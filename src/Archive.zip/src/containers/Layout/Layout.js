import React, { Component } from 'react';

import Header from '../../components/header/header'
class Layout extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <Header />
        )
    }
}

export default Layout;