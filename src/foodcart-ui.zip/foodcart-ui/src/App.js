import React from 'react';
import './App.scss';
import Layout from './containers/Layout/Layout'
function App() {
  return (
    <Layout />
  );
}

export default App;
