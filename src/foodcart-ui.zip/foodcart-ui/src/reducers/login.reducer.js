const initialState = {
    loginState: false
}
const reducer = (state = initialState, actions) => {
    switch (actions.type) {
        case 'SHOW_LOGIN':
            return {
                ...state,
                loginState: true
            }
        case 'HIDE_LOGIN': {
            debugger;
            return {
                ...state,
                loginState: false
            }
        }
        default:
            return state;
    }
}
export default reducer;