import React, { Component } from 'react';
import FoodFilters from '../../components/FoodFilters/FoodFilters';
import FoodItems from '../../components/FoodItems/FoodItems'
class FoodLayout extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div class="food-container">
                <div className="food-container__filters">
                    <FoodFilters />
                </div>
                <div className="food-container__items">
                    <FoodItems />
                </div>
            </div>
        )

    }
}
export default FoodLayout;