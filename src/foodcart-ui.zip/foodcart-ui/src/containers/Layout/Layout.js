import React, { Component } from 'react';
import Header from '../../components/header/header';
import loginActions from '../../actions/login.actions';
import { connect } from 'react-redux';
import Login from '../../components/Login/Login';
import Backdrop from '../../components/UI/Backdrop/Backdrop';
import Home from '../../components/Home/Home';
import FoodLayout from '../FoodLayout/FoodLayout';
class Layout extends Component {
    render() {
        return (
            <React.Fragment>
                <Header clicked={this.props.loginOpen} />
                <Home />
                <FoodLayout />
                {this.props.loginState ? <Login animState={this.props.loginState} loginClose={this.props.loginClose} /> : null}
                {this.props.loginState ? <Backdrop /> : null}
            </React.Fragment>
        )
    }
}
const mapStateToProps = state => {

    return {
        loginState: state.login.loginState
    }
}

const mapDispatchToProps = dispatch => {
    return {
        loginOpen: (e) => dispatch(loginActions.loginOpen(e)),
        loginClose: (e) => dispatch(loginActions.loginClose(e))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Layout);