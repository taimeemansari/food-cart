import React from 'react';

const Home = (props) => {
    return (
        <React.Fragment>
            <div className="home-container">
                <div className="home-container__search">
                    <div className="search">
                        <div className="search__heading">
                            <h1>Order Food for Online From the Best Restaurants</h1>
                        </div>
                        <div className="search__form">
                            <input type="text" name="city" placeholder="City" />
                            <input type="text" name="location" placeholder="Location" />
                            <button class="btn btn-success"><i class="fas fa-mug-hot"></i> Find Food</button>
                        </div>
                    </div>
                </div>
                <div className="home-container__stats">
                    <div className="stat">
                        <i className="fa fa-user"></i>
                        <div className="stat__details">
                            <h4>Users</h4>
                            <p>284</p>
                        </div>
                    </div>
                    <div className="stat">
                        <i className="fa fa-shopping-cart"></i>
                        <div className="stat__details">
                            <h4>Orders</h4>
                            <p>2228</p>
                        </div>
                    </div>
                    <div className="stat">
                        <i className="fa fa-shipping-fast"></i>
                        <div className="stat__details">
                            <h4>Deliverys</h4>
                            <p>1625</p>
                        </div>
                    </div>
                    <div className="stat">
                        <i className="fa fa-store-alt"></i>
                        <div className="stat__details">
                            <h4>Restaurants</h4>
                            <p>120</p>
                        </div>
                    </div>
                    <div className="stat">
                        <i class="fas fa-utensils"></i>
                        <div className="stat__details">
                            <h4>Food Items</h4>
                            <p>218</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="topres-container">
                <div className="topres-container__title">
                    <h2>Top Restaurants</h2>
                </div>
                <div className="topres-container__rlist">
                    <div class="restaurant">
                        <div className="restaurant__logo">
                            <img src="" alt="" />
                        </div>
                        <div className="restaurant__name">
                            Mirchi
               </div>
                    </div>
                    <div class="restaurant">
                        <div className="restaurant__logo">
                            <img src="" alt="" />
                        </div>
                        <div className="restaurant__name">
                            Mirchi
               </div>
                    </div>
                    <div class="restaurant">
                        <div className="restaurant__logo">
                            <img src="" alt="" />
                        </div>
                        <div className="restaurant__name">
                            Mirchi
               </div>
                    </div>
                    <div class="restaurant">
                        <div className="restaurant__logo">
                            <img src="" alt="" />
                        </div>
                        <div className="restaurant__name">
                            Mirchi
               </div>
                    </div>
                    <div class="restaurant">
                        <div className="restaurant__logo">
                            <img src="" alt="" />
                        </div>
                        <div className="restaurant__name">
                            Mirchi
               </div>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}

export default Home;