import React from 'react';
import FoodItem from './FoodItem/FoodItem'
const FoodFilters = (props) => {
    return (
        <FoodItem />
    )
}
export default FoodItem;