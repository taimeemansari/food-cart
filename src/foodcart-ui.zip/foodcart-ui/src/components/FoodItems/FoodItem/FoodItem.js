import React from 'react';
const FoodItem = (props) => {
    return (
        <div> Food Item</div>
    )
}
export default FoodItem;