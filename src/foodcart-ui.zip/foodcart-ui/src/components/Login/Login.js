import React from 'react';
import { Spring } from 'react-spring/renderprops'
const Login = (props) => {
    return (
        <Spring from={{ transform: 'translateX(100%)' }} to={{ transform: 'translateX(0%)' }}>
            {sprops => (
                <div style={sprops} className="login-container">
                    <button class="btn login-container__close" onClick={props.loginClose}><i class="fas fa-times"></i></button>
                    <div className="login-container__box">
                        <h4>Login</h4>
                        <div className="form-group">

                            <input type="text" name="email" placeholder="Email" />
                            <i className="fas fa-envelope icon"></i>
                        </div>
                        <div className="form-group">

                            <input type="password" name="password" placeholder="Password" />
                            <i className="fas fa-key icon"></i>
                        </div>
                        <p className="fpass"><a href="#">Forgot password ?</a></p>
                        <button type="button" className="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Login</button>
                    </div>
                </div >
            )}
        </Spring>
    )
}

export default Login;