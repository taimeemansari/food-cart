import React from 'react';

const FoodFilter = (props) => {
    return (
        <a href="#">Food Filter 1</a>
    )
}

export default FoodFilter;