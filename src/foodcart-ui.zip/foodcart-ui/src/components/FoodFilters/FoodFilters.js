import React from 'react';
import FoodFilter from './FoodFilter/FoodFilter'
const FoodFilters = (props) => {
    return (
        <div className="food-filters">
            <h4>Food Filters</h4>
            <FoodFilter />
        </div>

    )
}
export default FoodFilters;