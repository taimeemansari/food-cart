import { createBrowserHistory } from 'history';

const history = createBrowserHistory({ forceRefresh: true });

export default history;

