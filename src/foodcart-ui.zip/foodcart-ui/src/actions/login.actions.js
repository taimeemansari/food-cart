const loginActions = {
    loginOpen,
    loginClose
}
function loginOpen(event) {
    event.preventDefault();
    return dispatch => {
        debugger;
        dispatch(loginShow())
    }
}
export function loginShow() {
    debugger;
    return {
        type: "SHOW_LOGIN"
    }
}
function loginClose(event) {
    event.preventDefault();
    return dispatch => {
        debugger;
        dispatch(loginHide())
    }
}
export function loginHide() {
    debugger;
    return {
        type: "HIDE_LOGIN"
    }
}
export default loginActions;